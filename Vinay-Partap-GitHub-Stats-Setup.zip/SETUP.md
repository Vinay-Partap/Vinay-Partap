GITHUB PROFILE STATS SETUP

Repository:
Vinay-Partap/Vinay-Partap

1. Create these folders in your profile repository:
   .github/workflows/
   profile/

2. Upload:
   .github/workflows/github-profile-stats.yml

3. The workflow will automatically generate:
   profile/stats.svg
   profile/top-langs.svg
   profile/streak.svg

4. Replace the old broken "GitHub Stats" section in README.md with the
   contents of README-STATS-SNIPPET.md.

5. Commit and push the workflow.

6. Open:
   GitHub repository -> Actions -> Update GitHub Profile Stats

7. Click "Run workflow" once manually.

8. After it finishes, refresh your profile README.

The workflow then runs once every day at 03:00 UTC (08:30 IST) and updates
the generated SVG files only when their contents change.

No personal access token is required for public repository statistics.
The workflow uses the repository's built-in GITHUB_TOKEN.

IMPORTANT:
- Keep the generated SVG files in the profile repository.
- Do not use the old github-readme-stats.vercel.app URLs in README.md.
- Your project Live Demo links can remain exactly as they are.
